# java-ExcelFile
Reading and Writing Excel file in java
Two seperate classes for editing the Microsoft Excel file in java **
you need to add Apache-Poi Libarary to the project

**** دو کلاس برای خواندن و نوشتن در فایل های اکسل با استفاده از جاوا****
****Apache-poi  با استفاده از فایل های کتابخانه ای ****

